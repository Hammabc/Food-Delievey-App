
    function sendData(){
        alert("working")
        var name = document.getElementById('name').value
        var email = document.getElementById('email').value
        
        var password = document.getElementById('password').value
        let user = {
            email,
            name
        
        }
        firebase.database().ref('Restaurant').child(name).set(user)
        console.log(user);
    // console.log(email,password)
    firebase.auth().createUserWithEmailAndPassword(email,password)
        .then((data) => {
            setTimeout(() => {
                window.location = "resdashboard.html";
            }, 2000);
            
            
         console.log(data)
        })
        .catch((error) => {
            var errorMessage = error.message;
            console.log(errorMessage)
        });
}

function sendUser(){



    alert("working")
    var userName = document.getElementById('uname').value
    var userEmail = document.getElementById('email-u').value
    var userNumber = document.getElementById('u-number').value
    var userCountry = document.getElementById('country').value
    var userCity = document.getElementById('city').value
    var userPassword = document.getElementById('pass').value
    var adminName="user"
    let user = {
        userEmail,
        userName,
        userNumber,
        userCity,
        userCountry,
        adminName,
    }
    firebase.database().ref('Users').child(userName).set(user)
    // console.log(user)
    firebase.auth().createUserWithEmailAndPassword(userEmail, userPassword)
        .then((data) => {
            setTimeout(() => {
                 window.location = "userdashboard.html"
            }, 2000);

            
             console.log(data)
        })
        .catch((error) => {
            var errorMessage = error.message;
            console.log(errorMessage)
        });
}

function openCity(evt, cityName) {
    var i, x, tablinks;
    x = document.getElementsByClassName("city");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < x.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" w3-red", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " w3-red";
}





